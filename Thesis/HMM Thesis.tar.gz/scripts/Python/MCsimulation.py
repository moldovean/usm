#make sure you have python 2.7+ or python3+ and pip/pip3 installed respectively
#TO install QuantEcon library

# sudo apt-get install zlib1g zlib1g-dev libedit2 libedit-dev llvm-3.6 llvm-3.6-dev llvm-dev
# sudo -H pip3 install enum34 funcsigs

#pip install setuptools --upgrade
#sudo -H pip install wheel
#sudo pip install QuantEcon
