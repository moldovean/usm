# Created by Octave 4.0.0, Sat May 07 23:36:35 2016 EEST <adri@adri>
# name: A
# type: matrix
# rows: 3
# columns: 3
 0.971 0.029 0
 0.145 0.778 0.077
 0 0.508 0.492


# name: E
# type: matrix
# rows: 3
# columns: 1
 0.215
 0.015
 -0.18


# name: ans
# type: matrix
# rows: 3
# columns: 1
 1.000000000000001
 0.8515741223071079
 0.3894258776928927


# name: evals
# type: diagonal matrix
# rows: 3
# columns: 3
1.000000000000001
0.8515741223071079
0.3894258776928927


# name: evects
# type: matrix
# rows: 3
# columns: 3
 0.577350269189627 -0.1389311553845544 0.009868890764266851
 0.5773502691896255 0.572137074851313 -0.197913499461144
 0.5773502691896251 0.8083052032766433 0.9801698075977073


# name: mu
# type: matrix
# rows: 1
# columns: 3
 0.1 0.55 0.35


# name: payoffs
# type: matrix
# rows: 3
# columns: 1
 0.2092
 0.02975499999999999
 -0.07602


